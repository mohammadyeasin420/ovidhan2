import re
from pathlib import Path

ROOT_DIR = Path(__file__).parent
HEADER_FILE = ROOT_DIR / "header.html"
FOOTER_FILE = ROOT_DIR / "footer.html"

# Files to skip (by name)
EXCLUDE_FILES = ["header.html", "footer.html", "inject_layout.py", "styles.css"]

# Directories to skip entirely (recursive)
EXCLUDE_DIRS = ["word", "tools", "blog", "images", "mock-tests_backup"]  # add any others

def should_skip_file(file_path):
    """Return True if the file should be skipped."""
    if file_path.name in EXCLUDE_FILES:
        return True
    # Check if any parent directory is in EXCLUDE_DIRS
    for parent in file_path.parents:
        if parent.name in EXCLUDE_DIRS:
            return True
    return False

def remove_all_headers(content):
    pattern1 = r'<nav[^>]*class="[^"]*site-nav[^"]*"[^>]*>.*?</nav>'
    content = re.sub(pattern1, '', content, flags=re.DOTALL | re.IGNORECASE)
    pattern2 = r'<header[^>]*class="[^"]*site-header[^"]*"[^>]*>.*?</header>'
    content = re.sub(pattern2, '', content, flags=re.DOTALL | re.IGNORECASE)
    pattern3 = r'<nav[^>]*>.*?(?:mega-menu|Home.*Learn.*Dictionary).*?</nav>'
    content = re.sub(pattern3, '', content, flags=re.DOTALL | re.IGNORECASE)
    return content

def remove_all_footers(content):
    pattern1 = r'<footer[^>]*class="[^"]*site-footer[^"]*"[^>]*>.*?</footer>'
    content = re.sub(pattern1, '', content, flags=re.DOTALL | re.IGNORECASE)
    pattern2 = r'<div[^>]*class="[^"]*site-footer[^"]*"[^>]*>.*?</div>'
    content = re.sub(pattern2, '', content, flags=re.DOTALL | re.IGNORECASE)
    pattern3 = r'<footer[^>]*>.*?(?:©|Copyright|Made with).*?</footer>'
    content = re.sub(pattern3, '', content, flags=re.DOTALL | re.IGNORECASE)
    return content

def inject_layout(html_path):
    with open(html_path, 'r', encoding='utf-8') as f:
        content = f.read()

    with open(HEADER_FILE, 'r', encoding='utf-8') as f:
        header = f.read()
    with open(FOOTER_FILE, 'r', encoding='utf-8') as f:
        footer = f.read()

    content = remove_all_headers(content)
    content = remove_all_footers(content)

    # Inject header after <body>
    content = re.sub(r'(<body[^>]*>)', r'\1\n' + header, content, flags=re.IGNORECASE)
    # Inject footer before </body>
    content = re.sub(r'(</body>)', footer + '\n' + r'\1', content, flags=re.IGNORECASE)

    # Ensure styles.css is linked
    if '<link rel="stylesheet" href="styles.css"' not in content:
        content = re.sub(r'(<head[^>]*>)', r'\1\n    <link rel="stylesheet" href="styles.css" />', content, flags=re.IGNORECASE)

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ Injected: {html_path.relative_to(ROOT_DIR)}")

def main():
    if not HEADER_FILE.exists() or not FOOTER_FILE.exists():
        print("❌ header.html or footer.html missing.")
        return

    # Recursively find all HTML files, but skip excluded directories
    all_files = list(ROOT_DIR.rglob("*.html"))
    files_to_process = [f for f in all_files if not should_skip_file(f)]

    print(f"Found {len(all_files)} HTML files total. Processing {len(files_to_process)} (skipping others).")
    count = 0
    for file in files_to_process:
        inject_layout(file)
        count += 1

    print(f"\n🎉 Done! Processed {count} files.")

if __name__ == "__main__":
    main()