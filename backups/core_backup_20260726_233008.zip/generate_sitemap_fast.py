import os
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).parent
SITEMAP_FILE = ROOT / "sitemap.xml"
SITEMAP_INDEX_FILE = ROOT / "sitemap-index.xml"

# ── Folders to scan (skip /word/ to save time) ──
SCAN_FOLDERS = [
    ROOT,                      # Root pages (index.html, grammar.html, etc.)
    ROOT / "tools",            # Tools pages
    ROOT / "mock-tests",       # Mock test pages
    ROOT / "blog",             # Blog posts (if exists)
    ROOT / "images",           # Not needed but harmless
]

# ── Files to exclude ──
EXCLUDE_FILES = [
    "header.html",
    "footer.html",
    "styles.css",
    "robots.txt",
    "sitemap.xml",
    "sitemap-index.xml",
    ".gitignore",
    "CNAME",
]

# ── Sitemap settings ──
BASE_URL = "https://ovidhan.net"
SITEMAP_LIMIT = 50000  # Max URLs per sitemap file (Google limit)

def should_skip_file(filepath):
    """Check if a file should be skipped."""
    # Skip files in EXCLUDE_FILES list
    if filepath.name in EXCLUDE_FILES:
        return True
    # Skip non-HTML files
    if not filepath.suffix == '.html':
        return True
    # Skip files in /word/ folder (the big one)
    if 'word' in filepath.parts:
        return True
    # Skip files in /images/ folder
    if 'images' in filepath.parts:
        return True
    # Skip files starting with '_' or '.'
    if filepath.name.startswith('_') or filepath.name.startswith('.'):
        return True
    return False

def get_last_modified(filepath):
    """Get last modified date for a file."""
    try:
        mtime = filepath.stat().st_mtime
        return datetime.fromtimestamp(mtime).strftime('%Y-%m-%d')
    except:
        return datetime.now().strftime('%Y-%m-%d')

def get_priority(filepath):
    """Get priority based on file location."""
    name = filepath.name
    if name == 'index.html':
        return '1.0'
    elif name in ['learn.html', 'grammar.html', 'dictionary.html', 'speaking.html', 'writing.html', 'practice.html']:
        return '0.9'
    elif name in ['assessment.html', 'exam-prep.html', 'tools.html', 'bangladesh.html', 'blog.html']:
        return '0.8'
    elif filepath.parent.name in ['mock-tests', 'tools']:
        return '0.7'
    else:
        return '0.6'

def get_changefreq(filepath):
    """Get change frequency based on file type."""
    name = filepath.name
    if name == 'index.html':
        return 'daily'
    elif name in ['learn.html', 'grammar.html', 'dictionary.html']:
        return 'weekly'
    elif filepath.parent.name == 'mock-tests':
        return 'monthly'
    elif filepath.parent.name == 'blog':
        return 'weekly'
    else:
        return 'monthly'

def get_relative_path(filepath):
    """Get the URL path relative to the root."""
    rel = filepath.relative_to(ROOT)
    return str(rel).replace('\\', '/')

def generate_sitemap():
    """Generate sitemap.xml by scanning only specified folders."""
    print("🔍 Scanning for HTML files (fast mode - skipping /word/)...")
    
    urls = []
    scanned_count = 0
    
    for folder in SCAN_FOLDERS:
        if not folder.exists():
            continue
        for filepath in folder.rglob('*.html'):
            if should_skip_file(filepath):
                continue
            scanned_count += 1
            rel_path = get_relative_path(filepath)
            url = f"{BASE_URL}/{rel_path}"
            lastmod = get_last_modified(filepath)
            priority = get_priority(filepath)
            changefreq = get_changefreq(filepath)
            
            urls.append({
                'loc': url,
                'lastmod': lastmod,
                'changefreq': changefreq,
                'priority': priority
            })
    
    print(f"📊 Found {len(urls)} pages to include in sitemap (scanned {scanned_count} files, skipped /word/ folder).")
    
    if not urls:
        print("⚠️ No URLs found! Check your scan folders.")
        return
    
    # ── Generate sitemap XML ──
    root = ET.Element("urlset", xmlns="http://www.sitemaps.org/schemas/sitemap/0.9")
    
    # Sort URLs alphabetically
    urls.sort(key=lambda x: x['loc'])
    
    for url_data in urls:
        url_elem = ET.SubElement(root, "url")
        
        loc = ET.SubElement(url_elem, "loc")
        loc.text = url_data['loc']
        
        lastmod = ET.SubElement(url_elem, "lastmod")
        lastmod.text = url_data['lastmod']
        
        changefreq = ET.SubElement(url_elem, "changefreq")
        changefreq.text = url_data['changefreq']
        
        priority = ET.SubElement(url_elem, "priority")
        priority.text = url_data['priority']
    
    # Write sitemap.xml
    tree = ET.ElementTree(root)
    tree.write(SITEMAP_FILE, encoding='utf-8', xml_declaration=True)
    
    print(f"✅ Sitemap generated: {SITEMAP_FILE} ({len(urls)} URLs)")
    print(f"📁 File size: {SITEMAP_FILE.stat().st_size:,} bytes")

def generate_sitemap_index():
    """Generate sitemap-index.xml (for large sites with multiple parts)."""
    # Check if we need a sitemap index (more than 50,000 URLs)
    # For simplicity, we'll just create a simple index pointing to the main sitemap
    
    root = ET.Element("sitemapindex", xmlns="http://www.sitemaps.org/schemas/sitemap/0.9")
    
    sitemap_elem = ET.SubElement(root, "sitemap")
    loc = ET.SubElement(sitemap_elem, "loc")
    loc.text = f"{BASE_URL}/sitemap.xml"
    lastmod = ET.SubElement(sitemap_elem, "lastmod")
    lastmod.text = datetime.now().strftime('%Y-%m-%d')
    
    tree = ET.ElementTree(root)
    tree.write(SITEMAP_INDEX_FILE, encoding='utf-8', xml_declaration=True)
    print(f"✅ Sitemap index generated: {SITEMAP_INDEX_FILE}")

def main():
    """Main function."""
    print("="*60)
    print("🚀 OVIDHAN SITEMAP GENERATOR (FAST MODE)")
    print("="*60)
    print()
    
    generate_sitemap()
    
    # Generate sitemap index (optional, for completeness)
    # generate_sitemap_index()
    
    print()
    print("="*60)
    print("✅ Sitemap generation complete!")
    print(f"📊 Total pages: {len(open(SITEMAP_FILE).readlines())}")
    print("="*60)

if __name__ == "__main__":
    main()